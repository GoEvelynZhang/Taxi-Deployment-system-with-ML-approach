##This part of Visualization is contributed by Yuxin Zhang

##This file explains how I proceed the visualization
##The visualization contains several views:
1. Three section mapping in Haikou
2. Road mapping in Haikou [multipolyline]
3. Sectional demand & congestion mapping by hour in 2017-06-15


There are three folders in the file:
1. orderData contains the 24 hourly sectional order data directly saved from python, one “process.js” processing the data into dictionary, with keys of file name and values an array of array containing the section_id and the order_number; And one proceeded result dataset called “result.json”

2. congData contains the 24 hourly sectional congestion data directly saved from python, one “process.js” processing the data into dictionary, with keys of file name and values an array of array containing the section_id and the tti; And one proceeded result dataset called “result1.json”

3. The visualization contains “processed_boundary” as the raw dataset provided in the congestion dataset by DiDi; I also contains one “geojson2h3.js” file, which is the imported package to assist with transforming the H3 section_id to geojson polygon in leaflet.


The visualization generally uses the Geojson feature mapping framework offered by the Leaflet package. A lot of effort is put into the data process and conversion.

