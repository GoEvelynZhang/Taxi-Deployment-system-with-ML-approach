const fs = require('fs');

const data = {};
fs.readdirSync('.').forEach(d => {
  if (d.indexOf('.') !== -1) return;
  data[d] = fs.readFileSync(d)
    .toString()
    .split('\n')
    .slice(1)
    .filter(Boolean)
    .map(a => a.split(',').slice(1,3))
    .map(a => (a[1] = parseFloat(a[1])) && false || a)
});

fs.writeFileSync('result.json', JSON.stringify(data));
