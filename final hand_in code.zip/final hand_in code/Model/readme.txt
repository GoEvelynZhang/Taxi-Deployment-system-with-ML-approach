##Contributor of the Model: Yixiang Xiao, Yuxin Zhang, Xiyan Can

##This Model section contains the three folders, and jointly covers the whole process of the data-mining, preprocessing, filtering & merging, base model and the initial stacking training and predicting

1. Data crawling & process & Merge ctonain
2. Base model folder contains four models we added in out stacking prediction model process. They are kept in separate files: Average (Baseline), SVR, Decision Tree, Neural Network

3. Stacking folder contains the final stacked model for order (as mentioned in the presentation, we did not use stack for congestion at last)

4. data folder contains the data for congestion and order count that can be directly used for model training.